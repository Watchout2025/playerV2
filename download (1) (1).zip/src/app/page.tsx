"use client";

import HlsPlayer from '@/components/hls-player';
import { useSearchParams } from 'next/navigation';

export default function Home() {
  const searchParams = useSearchParams();
  const videoSrc = searchParams.get('url') || "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8";

  return (
    <main className="h-screen w-screen bg-black">
      <HlsPlayer src={videoSrc} />
    </main>
  );
}
