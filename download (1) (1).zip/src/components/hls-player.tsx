"use client";

import { cn } from "@/lib/utils";
import {
  Play,
  Volume2,
  VolumeX,
} from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
import { Slider } from "./ui/slider";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "./ui/dropdown-menu";
import { useIsMobile } from "@/hooks/use-mobile";

declare global {
  interface Window {
    Hls: any;
  }
}

interface HlsPlayerProps {
  src: string;
}

const PauseIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}><path fill="currentColor" fillRule="evenodd" d="M4.5 3a.5.5 0 0 0-.5.5v17c0 .28.22.5.5.5h5a.5.5 0 0 0 .5-.5v-17a.5.5 0 0 0-.5-.5zm10 0a.5.5 0 0 0-.5.5v17c0 .28.22.5.5.5h5a.5.5 0 0 0 .5-.5v-17a.5.5 0 0 0-.5-.5z" clipRule="evenodd"/></svg>
);

const SubtitlesIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}><path fill="currentColor" fillRule="evenodd" d="M1 3a1 1 0 0 1 1-1h20a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-3v3a1 1 0 0 1-1.55.83L11.7 18H2a1 1 0 0 1-1-1zm2 1v12h9.3l.25.17L17 19.13V16h4V4zm7 5H5V7h5zm9 2h-5v2h5zm-7 2H5v-2h7zm7-6h-7v2h7z" clipRule="evenodd"/></svg>
);

const FullscreenEnterIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}><path fill="currentColor" fillRule="evenodd" d="M0 5c0-1.1.9-2 2-2h7v2H2v4H0zm22 0h-7V3h7a2 2 0 0 1 2 2v4h-2zM2 15v4h7v2H2a2 2 0 0 1-2-2v-4zm20 4v-4h2v4a2 2 0 0 1-2 2h-7v-2z" clipRule="evenodd"/></svg>
);

const FullscreenExitIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg viewBox="0 0 24 24" width="24" height="24" data-icon="FullscreenExitMedium" data-icon-id=":r42:" aria-hidden="true" data-uia="control-fullscreen-exit" xmlns="http://www.w3.org/2000/svg" fill="none" role="img" {...props}><path fill="currentColor" fillRule="evenodd" d="M24 8h-5V3h-2v7h7zM0 16h5v5h2v-7H0zm7-6H0V8h5V3h2zm12 11v-5h5v-2h-7v7z" clipRule="evenodd"></path></svg>
);

const RewindIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}><path fill="currentColor" fillRule="evenodd" d="M11.02 2.05A10 10 0 1 1 2 12H0a12 12 0 1 0 5-9.75V1H3v4a1 1 0 0 0 1 1h4V4H6a10 10 0 0 1 5.02-1.95M2 4v3h3v2H1a1 1 0 0 1-1-1V4zm12.13 12q-.88 0-1.53-.42-.64-.44-1-1.22a5 5 0 0 1-.35-1.86q0-1.05.35-1.85.36-.79 1-1.22A2.7 2.7 0 0 1 14.13 9a2.65 2.65 0 0 1 2.52 1.65q.35.79.35 1.85 0 1.07-.35 1.86a3 3 0 0 1-1.01 1.22 2.7 2.7 0 0 1-1.52.42m0-1.35q.59 0 .91-.56.34-.56.34-1.59 0-1.01-.34-1.58-.33-.57-.91-.57-.6 0-.92.57-.34.56-.34 1.58t.34 1.6q.33.54.91.55m-5.53 1.2v-5.13l-1.6.42V9.82l3.2-.8v6.84z" clipRule="evenodd"/></svg>
);

const ForwardIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}><path fill="currentColor" fillRule="evenodd" d="M6.44 3.69A10 10 0 0 1 18 4h-2v2h4a1 1 0 0 0 1-1V1h-2v1.25A12 12 0 1 0 24 12h-2A10 10 0 1 1 6.44 3.69M22 4v3h-3v2h4a1 1 0 0 0 1-1V4zm-9.4 11.58q.66.42 1.53.42a2.7 2.7 0 0 0 1.5-.42q.67-.44 1.02-1.22.35-.8.35-1.86 0-1.05-.35-1.85A2.65 2.65 0 0 0 14.13 9a2.7 2.7 0 0 0-1.53.43q-.64.44-1 1.22a4.5 4.5 0 0 0-.35 1.85q0 1.07.35 1.86.36.78 1 1.22m2.44-1.49q-.33.56-.91.56-.6 0-.92-.56-.34-.56-.34-1.59 0-1.01.34-1.58.33-.57.91-.57.6 0 .92.57.34.56.34 1.58t-.34 1.6M8.6 10.72v5.14h1.6V9.02l-3.2.8v1.32z" clipRule="evenodd"/></svg>
);

const PlaybackSpeedIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" aria-hidden="true" {...props}><path fill="currentColor" fillRule="evenodd" d="M19.06 6.27a9.7 9.7 0 0 0-14.12 0 10.8 10.8 0 0 0 0 14.82L3.5 22.47a12.8 12.8 0 0 1 0-17.59 11.7 11.7 0 0 1 17 0 12.8 12.8 0 0 1 0 17.59l-1.44-1.38a10.8 10.8 0 0 0 0-14.82M15 14a3 3 0 1 1-1.7-2.7l3-3 1.4 1.4-3 3q.3.6.3 1.3" clipRule="evenodd"/></svg>
);


const HlsPlayer: React.FC<HlsPlayerProps> = ({ src }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerContainerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<any>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [audioTracks, setAudioTracks] = useState<any[]>([]);
  const [currentAudioTrack, setCurrentAudioTrack] = useState(-1);
  const [subtitleTracks, setSubtitleTracks] = useState<any[]>([]);
  const [currentSubtitleTrack, setCurrentSubtitleTrack] = useState(-1);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const isMobile = useIsMobile();


  useEffect(() => {
    const videoElement = videoRef.current;
    if (!videoElement) return;

    const initializePlayer = () => {
      if (window.Hls && window.Hls.isSupported()) {
        const hls = new window.Hls();
        hlsRef.current = hls;
        
        hls.on(window.Hls.Events.AUDIO_TRACKS_UPDATED, (event, data) => {
            setAudioTracks(hls.audioTracks);
            if (hls.audioTrack === -1) {
              const defaultTrack = hls.audioTracks.findIndex(track => track.default);
              hls.audioTrack = defaultTrack !== -1 ? defaultTrack : 0;
            }
            setCurrentAudioTrack(hls.audioTrack);
        });

        hls.on(window.Hls.Events.SUBTITLE_TRACKS_UPDATED, (event, data) => {
            setSubtitleTracks(hls.subtitleTracks);
             if (hls.subtitleTrack === -1) {
                const defaultTrack = hls.subtitleTracks.findIndex(track => track.default);
                hls.subtitleTrack = defaultTrack !== -1 ? defaultTrack : -1;
            }
            setCurrentSubtitleTrack(hls.subtitleTrack);
        });

        hls.loadSource(src);
        hls.attachMedia(videoElement);
      } else if (videoElement.canPlayType("application/vnd.apple.mpegurl")) {
        videoElement.src = src;
      }
    };
    
    const scriptCheckInterval = setInterval(() => {
        if(window.Hls) {
            clearInterval(scriptCheckInterval);
            initializePlayer();
        }
    }, 100);

    const handleTimeUpdate = () => {
      if (!videoElement.duration) return;
      setCurrentTime(videoElement.currentTime);
      setProgress((videoElement.currentTime / videoElement.duration) * 100);
    };

    const handleProgress = () => {
        if (!videoElement.duration) return;
        if (videoElement.buffered.length > 0) {
            const bufferedEnd = videoElement.buffered.end(videoElement.buffered.length - 1);
            setBuffered((bufferedEnd / videoElement.duration) * 100);
        }
    }

    const handleDurationChange = () => {
      if (videoElement.duration !== Infinity) {
        setDuration(videoElement.duration);
      }
    };

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    
    const syncVolumeFromVideo = () => {
        setVolume(videoElement.volume);
        setIsMuted(videoElement.muted);
    };
    
    const handleFullscreenChange = () => {
        const isCurrentlyFullscreen = !!document.fullscreenElement;
        setIsFullscreen(isCurrentlyFullscreen);
    };

    videoElement.addEventListener("timeupdate", handleTimeUpdate);
    videoElement.addEventListener("progress", handleProgress);
    videoElement.addEventListener("durationchange", handleDurationChange);
    videoElement.addEventListener("play", handlePlay);
    videoElement.addEventListener("pause", handlePause);
    videoElement.addEventListener("volumechange", syncVolumeFromVideo);
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    document.addEventListener("webkitfullscreenchange", handleFullscreenChange);

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
      }
      clearInterval(scriptCheckInterval);
      videoElement.removeEventListener("timeupdate", handleTimeUpdate);
      videoElement.removeEventListener("progress", handleProgress);
      videoElement.removeEventListener("durationchange", handleDurationChange);
      videoElement.removeEventListener("play", handlePlay);
      videoElement.removeEventListener("pause", handlePause);
      videoElement.removeEventListener("volumechange", syncVolumeFromVideo);
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
      document.removeEventListener("webkitfullscreenchange", handleFullscreenChange);
    };
  }, [src]);

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
    }
  };
  
  const seek = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime += seconds;
    }
  };

  const handleSeekSliderChange = (value: number[]) => {
    if (videoRef.current && duration) {
      const newProgress = value[0];
      const seekTime = (newProgress / 100) * duration;
      videoRef.current.currentTime = seekTime;
      setProgress(newProgress);
      setCurrentTime(seekTime);
    }
  };

  const handleVolumeSliderChange = (value: number[]) => {
    if (videoRef.current) {
        const newVolume = value[0] / 100;
        videoRef.current.volume = newVolume;
        videoRef.current.muted = newVolume === 0;
    }
  };

  const handleAudioTrackChange = (trackId: string) => {
      const newTrackId = parseInt(trackId, 10);
      if (hlsRef.current) {
        hlsRef.current.audioTrack = newTrackId;
        setCurrentAudioTrack(newTrackId);
      }
  };
  
  const handleSubtitleTrackChange = (trackId: string) => {
    const newTrackId = parseInt(trackId, 10);
    if (hlsRef.current) {
        hlsRef.current.subtitleTrack = newTrackId;
        setCurrentSubtitleTrack(newTrackId);
    }
  };

  const handlePlaybackRateChange = (rate: string) => {
    const newRate = parseFloat(rate);
    if (videoRef.current) {
        videoRef.current.playbackRate = newRate;
        setPlaybackRate(newRate);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      const newMuted = !videoRef.current.muted;
      videoRef.current.muted = newMuted;
      if (!newMuted && videoRef.current.volume === 0) {
        videoRef.current.volume = 0.5;
      }
    }
  };

  const toggleFullscreen = () => {
    const playerContainer = playerContainerRef.current;
    if (!playerContainer) return;
    if (!isFullscreen) {
      if (playerContainer.requestFullscreen) playerContainer.requestFullscreen();
      else if ((playerContainer as any).webkitRequestFullscreen) (playerContainer as any).webkitRequestFullscreen();
    } else {
      if (document.exitFullscreen) document.exitFullscreen();
      else if ((document as any).webkitExitFullscreen) (document as any).webkitExitFullscreen();
    }
  };
  
  const formatTime = (timeInSeconds: number) => {
    if (isNaN(timeInSeconds) || timeInSeconds < 0) return "00:00";
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  };

  const resetControlsTimeout = () => {
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if(isPlaying && !isMenuOpen) setShowControls(false);
    }, 3000);
  };

  const handlePlayerMouseMove = () => {
    setShowControls(true);
    resetControlsTimeout();
  }
  
  useEffect(() => {
    if (!isPlaying) {
      setShowControls(true);
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    } else {
        resetControlsTimeout();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying, isMenuOpen]);

  const handlePlayerClick = () => {
    if (isMobile) {
      setShowControls(prev => !prev);
    } else {
      togglePlayPause();
    }
  }

  const getLanguageName = (languageCode: string) => {
    if (!languageCode) return "Unknown";
    try {
      const language = new Intl.DisplayNames(['en'], { type: 'language' }).of(languageCode);
      return language ? capitalizeFirstLetter(language) : capitalizeFirstLetter(languageCode);
    } catch (error) {
      return capitalizeFirstLetter(languageCode);
    }
  };

  const capitalizeFirstLetter = (string: string) => {
    if (!string) return string;
    return string.charAt(0).toUpperCase() + string.slice(1);
  };

  return (
    <div
      ref={playerContainerRef}
      className="relative w-full h-full bg-black group/player overflow-hidden"
      onMouseMove={handlePlayerMouseMove}
      onMouseLeave={() => { if(isPlaying && !isMenuOpen) setShowControls(false); }}
      onClick={handlePlayerClick}
    >
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        playsInline
      />
      
      {showControls && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="flex items-center justify-center w-full max-w-xs sm:max-w-md">
            <button
              onClick={(e) => { e.stopPropagation(); seek(-10); }}
              className={cn(
                "p-2 text-white rounded-full transition-transform hover:scale-110 pointer-events-auto",
                "opacity-0 group-hover/player:opacity-100 group-focus/player:opacity-100"
              )}
              aria-label="Rewind 10 seconds"
            >
              <RewindIcon className="w-8 h-8" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); togglePlayPause(); }}
              className={cn(
                "p-3 text-white rounded-full transition-transform hover:scale-110 pointer-events-auto mx-2 sm:mx-4",
                !isPlaying && "opacity-100",
                isPlaying && "opacity-0 group-hover/player:opacity-100 group-focus/player:opacity-100"
              )}
              aria-label={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? (
                <PauseIcon className="w-10 h-10 sm:w-12 sm:h-12 fill-current" />
              ) : (
                <Play className="w-10 h-10 sm:w-12 sm:h-12 ml-1 fill-current" />
              )}
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); seek(10); }}
              className={cn(
                "p-2 text-white rounded-full transition-transform hover:scale-110 pointer-events-auto",
                "opacity-0 group-hover/player:opacity-100 group-focus/player:opacity-100"
              )}
              aria-label="Forward 10 seconds"
            >
              <ForwardIcon className="w-8 h-8" />
            </button>
          </div>
        </div>
      )}

      <div
        className={cn(
          "absolute bottom-0 left-0 right-0 z-10 text-white transition-all duration-300",
          showControls ? "opacity-100 translate-y-0" : "opacity-0 translate-y-full pointer-events-none",
          "bg-gradient-to-t from-black/70 to-transparent px-2 sm:px-4 pt-2"
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-full px-1 flex items-center gap-2">
            <Slider
              value={[progress]}
              buffer={buffered}
              onValueChange={handleSeekSliderChange}
              className="w-full h-2 cursor-pointer group/slider"
              rangeClassName="bg-primary"
              thumbClassName="h-3.5 w-3.5 bg-primary"
              aria-label="Seek bar"
            />
            <div className="text-sm font-mono flex-shrink-0">
              <span>{formatTime(currentTime)}</span> / <span>{formatTime(duration)}</span>
            </div>
        </div>

        <div className="flex items-center gap-1 sm:gap-2">
          <button onClick={togglePlayPause} className="p-2 sm:p-2" aria-label={isPlaying ? "Pause" : "Play"}>
            {isPlaying ? <PauseIcon className="w-6 h-6 sm:w-7 sm:h-7 fill-white" /> : <Play className="w-6 h-6 sm:w-7 sm:h-7 ml-0.5 fill-white" />}
          </button>
          <button onClick={() => seek(-10)} className="p-2 hidden sm:block" aria-label="Rewind 10 seconds">
            <RewindIcon className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
          <button onClick={() => seek(10)} className="p-2 hidden sm:block" aria-label="Forward 10 seconds">
            <ForwardIcon className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
          
          <div className="relative group/volume">
              <button onClick={toggleMute} className="p-2" aria-label={isMuted ? "Unmute" : "Mute"}>
                {isMuted || volume === 0 ? <VolumeX className="w-5 h-5 sm:w-6 sm:h-6" /> : <Volume2 className="w-5 h-5 sm:w-6 sm:h-6" />}
              </button>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 pb-2 opacity-0 group-hover/volume:opacity-100 transition-opacity pointer-events-none group-hover/volume:pointer-events-auto hidden sm:block">
                  <div className="h-24 p-2 flex justify-center">
                      <Slider
                          value={[isMuted ? 0 : volume * 100]}
                          onValueChange={handleVolumeSliderChange}
                          max={100}
                          orientation="vertical"
                          className="w-2"
                          rangeClassName="bg-primary"
                          aria-label="Volume control"
                      />
                  </div>
              </div>
          </div>
          
          <div className="flex-grow"></div>

          <DropdownMenu onOpenChange={setIsMenuOpen}>
            <DropdownMenuTrigger asChild>
                <button className="p-2" onClick={(e) => e.stopPropagation()}>
                    <PlaybackSpeedIcon className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
                align="end"
                className="bg-black/80 border-white/20 text-white"
                onClick={(e) => e.stopPropagation()}
            >
                <DropdownMenuLabel>Playback Speed</DropdownMenuLabel>
                <DropdownMenuRadioGroup value={playbackRate.toString()} onValueChange={handlePlaybackRateChange}>
                    {[0.5, 0.75, 1, 1.25, 1.5, 2].map((rate) => (
                        <DropdownMenuRadioItem key={rate} value={rate.toString()} className="cursor-pointer">
                            {rate === 1 ? "Normal" : `${rate}x`}
                        </DropdownMenuRadioItem>
                    ))}
                </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu onOpenChange={setIsMenuOpen}>
            <DropdownMenuTrigger asChild>
              <button className="p-2" onClick={(e) => e.stopPropagation()}>
                <SubtitlesIcon className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              className="bg-black/80 border-white/20 text-white"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex flex-col sm:flex-row gap-4 p-2">
                <div>
                  <DropdownMenuLabel>Audio</DropdownMenuLabel>
                  <DropdownMenuRadioGroup value={currentAudioTrack.toString()} onValueChange={handleAudioTrackChange}>
                    {audioTracks.length > 1 ? audioTracks.map((track) => (
                      <DropdownMenuRadioItem key={track.id} value={track.id.toString()} className="cursor-pointer">
                        {getLanguageName(track.lang) || capitalizeFirstLetter(track.name)}
                      </DropdownMenuRadioItem>
                    )) : (
                      <DropdownMenuRadioItem value="-1" disabled className="cursor-pointer">
                        Default
                      </DropdownMenuRadioItem>
                    )}
                  </DropdownMenuRadioGroup>
                </div>
                <DropdownMenuSeparator orientation="vertical" className="bg-white/20 h-auto hidden sm:block"/>
                <div className="sm:hidden">
                    <DropdownMenuSeparator className="bg-white/20"/>
                </div>
                <div>
                  <DropdownMenuLabel>Subtitles</DropdownMenuLabel>
                  <DropdownMenuRadioGroup value={currentSubtitleTrack.toString()} onValueChange={handleSubtitleTrackChange}>
                    <DropdownMenuRadioItem value="-1" className="cursor-pointer">
                      Off
                    </DropdownMenuRadioItem>
                    {subtitleTracks.map((track) => (
                      <DropdownMenuRadioItem key={track.id} value={track.id.toString()} className="cursor-pointer">
                        {getLanguageName(track.lang) || capitalizeFirstLetter(track.name)}
                      </DropdownMenuRadioItem>
                    ))}
                  </DropdownMenuRadioGroup>
                </div>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          <button onClick={toggleFullscreen} className="p-2" aria-label={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}>
            {isFullscreen ? <FullscreenExitIcon className="w-5 h-5 sm:w-6 sm:h-6" /> : <FullscreenEnterIcon className="w-5 h-5 sm:w-6 sm:h-6" />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default HlsPlayer;
